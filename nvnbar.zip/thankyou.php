<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/about.css">
<title>Contact Me</title>
</head>
<body>
<h2>Thank you!</h2>
  <footer>
          <div id="toSides">
      <a href="designer.html">DESIGNER</a>
      <a href="developer.html">DEVELOPER</a>
    </div>
  </footer>
</div>

</body>
</html>
